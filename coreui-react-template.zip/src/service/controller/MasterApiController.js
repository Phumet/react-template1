import AsyncStorage from '@react-native-community/async-storage';
import MasterApiManager from './MasterApiManager'


export default class MasterApiController {

    async getAllDealer() {
        var dealer = await new MasterApiManager().getAllDealer();
        console.log(dealer)
        return dealer;
    }

    async getAllShowrooms() {
        let showroom = await new MasterApiManager().getAllShowrooms();
        return showroom;
    }

    async getAllRegion() {
        let region = await new MasterApiManager().getAllRegion();
        return region;
    }

    async getAllArea() {
        let area = await new MasterApiManager().getAllArea();
        return area;
    }
    
    async getAllSaleteam() {
        let saleteam = await new MasterApiManager().getAllSaleteam();
        return saleteam;
    }

    async getAllSalecode() {
        let salecode = await new MasterApiManager().getAllSalecode();
        return salecode;
    }

}
