
import axios from 'axios'

export  default  class LoginManager {

//    async isLogin(login){
//        return await axios.post('http://115.31.145.20/srisawad-api/api/Authentication/auth', 'headers: {"Content-Type": "application/json"}', {params:{
//             username: login.username, password: login.password, grantType: "password"
//        }})
//    }

    async isLogin(login){
        console.log("Username= "+login.username + "Password = "+login.password)
        return await axios({
      method: "post",
      url: "http://115.31.145.20/srisawad-api/api/Authentication/auth",
      headers: {
        "Content-Type": "application/json",
      },
      data: { username: login.username, password: login.password, grantType: "mobile" },
    })
      .then((response) => {
          console.log(response.data.authToken)
         return  response.data
      })
      .catch((err) => {
        console.error(err);
      });
      
  }
}