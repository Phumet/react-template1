import AsyncStorage from '@react-native-community/async-storage';
import LoginManager from '../controller/LoginManager'


export default class LoginController{


     doLogin(login){
        
        let lm = new LoginManager().isLogin(login);
        console.log("LM ", lm)
        let data = false;

     lm.then(function(result){
           console.log( result.authToken)    
           console.log( result.authenResult)
           data = JSON.stringify(result.authenResult.Success);
           console.log(data+"Status")
           AsyncStorage.setItem('token',JSON.stringify(result.authToken));
           
        })

        console.log(data+"Status")

         if (data === false) {
             console.log('No')
             return 0;
         } else {
             console.log('ok')
             return 1;
         }
    }

}