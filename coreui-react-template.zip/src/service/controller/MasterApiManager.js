
import axios from 'axios'

export default class MasterApiManager {

  // async isLogin(){
  //     return await axios.post('/api/DealerMaster',null,  {headers: {"Content-Type": "application/json"}})
  // }

  async getAllDealer() {
    return axios({
      method: "post",
      url: "/api/DealerMaster",
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((response) => {
        return response.data
      })
      .catch((err) => {
        console.error(err);
      });
  }
  async getAllShowrooms() {
    return axios({
      method: "post",
      url: "/api/ShowroomMaster",
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((response) => {
        return response.data
      })
      .catch((err) => {
        console.error(err);
      });
  }


  async getAllRegion() {
    return axios({
      method: "post",
      url: "/api/RegionMaster",
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((response) => {
        return response.data
      })
      .catch((err) => {
        console.error(err);
      });
  }

  async getAllArea() {
    return axios({
      method: "post",
      url: "/api/AreaMaster",
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((response) => {
        return response.data
      })
      .catch((err) => {
        console.error(err);
      });
  }

  async getAllSaleteam() {
    return axios({
      method: "post",
      url: "/api/MarketingTeamMaster",
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((response) => {
        return response.data
      })
      .catch((err) => {
        console.error(err);
      });
  }

  async getAllSalecode() {
    return axios({
      method: "post",
      url: "/api/MarketingStaffMaster",
      headers: {
        "Content-Type": "application/json",
      },
    })
      .then((response) => {
        return response.data
      })
      .catch((err) => {
        console.error(err);
      });
  }
}