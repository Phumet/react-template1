import React from 'react'
import { CFooter } from '@coreui/react'

const TheFooter = () => {
  return (
    <CFooter fixed={false}>
      <div>
        <span>Copyright © 2021 </span>
        <a href="/" target="_blank" rel="noopener noreferrer">SLEASING.</a>
        <span className="ml-1">&copy; All rights reserved.</span>
      </div>
      <div className="mfs-auto">
        <span className="mr-1">Version 1.0.0.0</span>
      </div>
    </CFooter>
  )
}

export default React.memo(TheFooter)
