import React from 'react'
import CIcon from '@coreui/icons-react'
import { freeSet } from '@coreui/icons'

const _nav =  [
  {
    _tag: 'CSidebarNavItem',
    name: 'Dashboard',
    to: '/dashboard',
    icon: <CIcon name="cil-speedometer" customClasses="c-sidebar-nav-icon"/>,
    badge: {
      color: 'info',
      text: 'NEW',
    }
  },
  {
    _tag: 'CSidebarNavDropdown',
    name: 'Report',
    route: '/report',
    icon: <CIcon content={freeSet.cilDescription} customClasses="c-sidebar-nav-icon" /> ,
    _children: [
      {
        _tag: 'CSidebarNavItem',
        name: 'Report For CFA',
        to: '/report/report-for-cfa',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Overdue 6 Month Report',
        to: '/report/report-overdue-6month',
      },
      {
        _tag: 'CSidebarNavItem',
        name: 'Application Status Report',
        to: '/report/report-application-status',
      },
    ],
  },
  {
    _tag: 'CSidebarNavDropdown',
    name: 'สินเชื่อ',
    route: '/credit',
    icon: <CIcon content={freeSet.cilCalculator} customClasses="c-sidebar-nav-icon" /> ,
    _children: [
      {
        _tag: 'CSidebarNavItem',
        name: 'คำนวน สินเชื่อ',
        to: '/credit/credit-calculate',
      },
    ],
  }
]

export default _nav
