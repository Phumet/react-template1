import React, { useState, useEffect } from "react";
import axios from "axios";
import DatePicker from "react-datepicker";
import "react-datepicker/src/stylesheets/datepicker.scss";
import "./AppcationStatusReport.css";


import Select from "react-select";
import makeAnimated from "react-select/animated";

import CIcon from "@coreui/icons-react";
import { freeSet } from "@coreui/icons";

import NumberFormat from "react-number-format";
import MasterApiController from '../../../service/controller/MasterApiController'
const AppcationStatusReport = () => {
  const animatedComponents = makeAnimated();

  const [startDate, setStartDate] = useState(new Date());

  const [dealerErrors, setDealerErrors] = useState(false);
  const [dealerData, setDealers] = useState({});

  const [showroomErrors, setShowroomErrors] = useState(false);
  const [showroomData, setShowrooms] = useState({});

  const [regionErrors, setRegionErrors] = useState(false);
  const [regionData, setRegions] = useState({});

  const [areaErrors, setAreaErrors] = useState(false);
  const [areaData, setAreas] = useState({});

  const [saleteamErrors, setSaleteamErrors] = useState(false);
  const [saleteamData, setSaleteams] = useState({});

  const [salecodeErrors, setSalecodeErrors] = useState(false);
  const [salecodeData, setSalecodes] = useState({});

  // async function getAllDealer() {
  //   axios({
  //     method: "post",
  //     url: "/api/DealerMaster",
  //     headers: {
  //       "Content-Type": "application/json",
  //     },
  //   })
  //     .then((response) => {
  //       setDealers(response.data);
  //     })
  //     .catch((err) => {
  //       setDealerErrors(err);
  //       console.error(err);
  //     });
  // }

  // async function getAllShowrooms() {
  //   axios({
  //     method: "post",
  //     url: "/api/ShowroomMaster",
  //     headers: {
  //       "Content-Type": "application/json",
  //     },
  //   })
  //     .then((response) => {
  //       setShowrooms(response.data);
  //     })
  //     .catch((err) => {
  //       setShowroomErrors(err);
  //       console.error(err);
  //     });
  // }

  // async function getAllRegion() {
  //   axios({
  //     method: "post",
  //     url: "/api/RegionMaster",
  //     headers: {
  //       "Content-Type": "application/json",
  //     },
  //   })
  //     .then((response) => {
  //       setRegions(response.data);
  //     })
  //     .catch((err) => {
  //       setRegionErrors(err);
  //       console.error(err);
  //     });
  // }

  // async function getAllArea() {
  //   axios({
  //     method: "post",
  //     url: "/api/AreaMaster",
  //     headers: {
  //       "Content-Type": "application/json",
  //     },
  //   })
  //     .then((response) => {
  //       setAreas(response.data);
  //     })
  //     .catch((err) => {
  //       setAreaErrors(err);
  //       console.error(err);
  //     });
  // }

  // async function getAllSaleteam() {
  //   axios({
  //     method: "post",
  //     url: "/api/MarketingTeamMaster",
  //     headers: {
  //       "Content-Type": "application/json",
  //     },
  //   })
  //     .then((response) => {
  //       setSaleteams(response.data);
  //     })
  //     .catch((err) => {
  //       setSaleteamErrors(err);
  //       console.error(err);
  //     });
  // }

  // async function getAllSalecode() {
  //   axios({
  //     method: "post",
  //     url: "/api/MarketingStaffMaster",
  //     headers: {
  //       "Content-Type": "application/json",
  //     },
  //   })
  //     .then((response) => {
  //       setSalecodes(response.data);
  //     })
  //     .catch((err) => {
  //       setSalecodeErrors(err);
  //       console.error(err);
  //     });
  // }
  const master  = new MasterApiController();

  async function getAllDealer() {
    const value = await master.getAllDealer();
    setDealers(value)
  }

  async function getAllShowrooms() {
    const value = await master.getAllShowrooms();
    setShowrooms(value)

  }

  async function getAllRegion() {
    const value = await master.getAllRegion();
    setRegions(value)

  }

  async function getAllArea() {
    const value = await master.getAllArea();
    setAreas(value)

  }

  async function getAllSaleteam() {
    const value = await master.getAllSaleteam();
    setSaleteams(value)

  }

  async function getAllSalecode() {
    const value = await master.getAllSalecode();
    setSalecodes(value)
  }

  useEffect(() => {
    getAllDealer();
    getAllShowrooms();
    getAllRegion();
    getAllArea();
    getAllSaleteam();
    getAllSalecode();
  }, []);

  const Appstatusoptions = [
    { value: 0, label: "Created" },
    { value: 1, label: "CV/CA worklist" },
    { value: 2, label: "On-Process" },
    { value: 3, label: "Complete CA" },
    { value: 4, label: "Pending OR" },
    { value: 5, label: "Approved" },
    { value: 6, label: "Decline" },
    { value: 7, label: "Contract" },
  ];
  const dealeroptions = [{dealer_id:null, value: null, label: "ทั้งหมด" }];
  {
    for (var i = 0; i < dealerData.length; i++) {
      {
        dealeroptions.push({
          dealer_id: dealerData[i].dealer_id,
          value: dealerData[i].dealer_code,
          label: dealerData[i].dealer_name_tha,
        });
      }
    }
  }

  const showroomoptions = [/*{ value: null, label: "ทั้งหมด" }*/];
  {
    for (var i = 0; i < showroomData.length; i++) {
      {
        showroomoptions.push({
          value: showroomData[i].show_room_full_code,
          label: showroomData[i].show_room_name_tha,
          dealer_id:showroomData[i].dealer_id
        });
      }
    }
  }

  const regionoptions = [{ region_id: null,value: 0, label: "All" }];
  {
    for (var i = 0; i < regionData.length; i++) {
      {
        regionoptions.push({
          region_id : regionData[i].region_id,
          value: regionData[i].region_code,
          label: regionData[i].region_name_tha,
        });
      }
    }
  }

const areaoptions = [/*{ zone_id: null ,value: null, label: "ทั้งหมด",region_id: null  }*/];
  {
    for (var i = 0; i < areaData.length; i++) {
      {
        areaoptions.push({
          zone_id: areaData[i].zone_id,
          value: areaData[i].zone_code,
          label: areaData[i].zone_name_tha,
          region_id:  areaData[i].region_id,
        });
      }
    }
  }

  const teamoptions = [/*{team_id: null ,value: null, label: "ทั้งหมด",  zone_id:null }*/];
  {
    for (var i = 0; i < saleteamData.length; i++) {
      {
        teamoptions.push({
          team_id: saleteamData[i].team_id,
          value: saleteamData[i].team_code,
          label: saleteamData[i].team_name_tha,
          zone_id: saleteamData[i].zone_id,
        });
      }
    }
  }

  const salecodetions = [/*{ team_id:null, value: null, label: "ทั้งหมด" }*/];
  {
    for (var i = 0; i < salecodeData.length; i++) {
      {
        salecodetions.push({
          team_id: salecodeData[i].team_id,
          value: salecodeData[i].marketing_code,
          label: salecodeData[i].mkt_full_name_tha,
        });
      }
    }
  }

  const [ApplicationDateFrom, setApplicationDateFrom] = useState(new Date());
  const [ApplicationDateTo, setApplicationDateTo] = useState(new Date());
  const [RegionCode, setRegionCode] = useState(null);
  const [AreaCode, setAreaCode] = useState(null);
  const [TeamCode, setTeamCode] = useState(null);
  const [SalesCode, setSalesCode] = useState(null);
  const [DealerCode, setDealerCode] = useState(null);
  const [ShowroomCode, setShowroomCode] = useState(null);
  const [OverrideFlag, setOverrideFlag] = useState(null);
  const [ApplicationNo, setApplicationNo] = useState(null);
  const [ApplicationStatus, setApplicationStatus] = useState([]);
  const [ContractDateFrom, setContractDateFrom] = useState(null);
  const [ContractDateTo, setContractDateTo] = useState(null);

  const handleChangeStatus = (e) => {
    
    setApplicationStatus(Array.isArray(e) ? e.map((x) => x.value) : []);

  };
  const handleChangeDealer = (e) => {
    if (e.value!=null || e.value!="") {
      setDealerCode(e.value);
    } else {
      setDealerCode(null);
    }
    
  };
  const handleChangeShowroom = (e) => {
    if (e.value!=null || e.value!="") {
      setShowroomCode(e.value);
    } else {
      setShowroomCode(null);
    }
    
  };

  const handleChangeRegion = (e) => {
    setAreaCode(null);
    setTeamCode(null);
    setSalesCode(null);
    if (e.value!=null || e.value!="") {
      setRegionCode(e.value);
    } else {
      setRegionCode(null);
    }
    
  };
  const handleChangeArea = (e) => {
    setTeamCode(null);
    setSalesCode(null);
    if (e.target.value!=null || e.target.value!="") {
      setAreaCode(e.target.value);
    } else {
      setAreaCode(null);
    }
    
  };
  const handleChangeTeamCode = (e) => {
    if (e.value!=null || e.value!="") {
      setTeamCode(e.value);
    } else {
      setTeamCode(null);
    }
  };
  const handleChangeSaleCode = (e) => {
    if (e.value!=null || e.value!="") {
      setSalesCode('"'+e.value+'"')
    } else {
      setSalesCode(null);
    }
  };

  function formatDate(string) {
    var options = {
      year: "numeric",
      month: "numeric",
      day: "numeric",
    };
    return new Date(string).toLocaleDateString([], options);
  }

  const [ResultSearchErrors, setResultSearchErrors] = useState(false);
  const [ResultSearchData, setResultSearchs] = useState({});

  const getResultSearch = () => {
    setResultSearchs({});
    if (ApplicationStatus != null && ApplicationStatus.length < 1) {
      setApplicationStatus(null);
    } else {
      axios({
        method: "post",
        url: "/api/SalesPerformanceTrackingReport",
        headers: {
          "Content-Type": "application/json",
        },
        data: {
          ApplicationDateFrom: getparsedateFormat(ApplicationDateFrom),
          ApplicationDateTo: getparsedateFormat(ApplicationDateTo),
          RegionCode: RegionCode,
          AreaCode: AreaCode,
          TeamCode: TeamCode,
          SalesCode: SalesCode,
          DealerCode: DealerCode,
          ShowroomCode: ShowroomCode,
          OverrideFlag: OverrideFlag,
          ApplicationNo: null,
          ApplicationStatus: ApplicationStatus,
          ContractDateFrom: ContractDateFrom
            ? getparsedateFormat(ContractDateFrom)
            : null,
          ContractDateTo: ContractDateTo
            ? getparsedateFormat(ContractDateTo)
            : null,
        },
      })
        .then((response) => {
          setResultSearchs(response.data);
          console.log("response: ", response.data);
        })
        .catch((err) => {
          setResultSearchErrors(err);
          console.error(err);
        });
    }
  };

  function getparsedateFormat(value) {
    if (value == null || value== "") {
      return null;
    } else {
      const ye = new Intl.DateTimeFormat("en", { year: "numeric" }).format(value);
      const mo = new Intl.DateTimeFormat("en", { month: "2-digit" }).format(value);
      const da = new Intl.DateTimeFormat("en", { day: "2-digit" }).format(value);
      const result = ye + "-" + mo + "-" + da;
  
      return result;
    }
   
  }
  const resSearch = [];
      const getGeneratePFD = () =>{
        //  var url = 'http://desktop-td39fih/ReportServer/Pages/ReportViewer.aspx?%2ftestReport%2fReport2&ApplicationDateFrom='+getparsedateFormat(ApplicationDateFrom)+'&ApplicationDateTo='+getparsedateFormat(ApplicationDateTo)+'&RegionCode='+RegionCode+'&AreaCode='+AreaCode+'&TeamCode='+TeamCode+'&SalesCode='+SalesCode+'&DealerCode='+DealerCode+'&ShowroomCode='+ShowroomCode+'&OverrideFlag='+OverrideFlag+'&ApplicationNo='+ApplicationNo+'&ApplicationStatus=null&ContractDateFrom='+getparsedateFormat(ContractDateFrom)+'&ContractDateTo='+getparsedateFormat(ContractDateTo)+'&rs:Format=PDF'
        if (ApplicationStatus.length != 0 ) {
          var strStatus = ""
          ApplicationStatus.map(x =>(strStatus += x+","))
          if (strStatus.endsWith(",")) {
            strStatus = strStatus.substring(0, strStatus.length - 1) + "";
          }
          var url = 'http://10.1.53.34/ReportServer/Pages/ReportViewer.aspx?%2fSaleReport%2fApplicationStatusReport1&ApplicationDateFrom='+getparsedateFormat(ApplicationDateFrom)+'&ApplicationDateTo='+getparsedateFormat(ApplicationDateTo)+'&RegionCode='+RegionCode+'&AreaCode='+AreaCode+'&TeamCode='+TeamCode+'&SalesCode='+SalesCode+'&DealerCode='+DealerCode+'&ShowroomCode='+ShowroomCode+'&OverrideFlag='+OverrideFlag+'&ApplicationNo='+ApplicationNo+'&ApplicationStatus='+'"'+strStatus+'"'+'&ContractDateFrom='+getparsedateFormat(ContractDateFrom)+'&ContractDateTo='+getparsedateFormat(ContractDateTo)+'&PrintBy=watcharin.k&rs:Command=Render&rc:Toolbar=True&rc:Parameters=False&rc:HTMLFragment=True&rs:Command=ClearSession&rs:Format=HTML4.0&rc:Zoom=Page Width'
        } else {  
          var url = 'http://10.1.53.34/ReportServer/Pages/ReportViewer.aspx?%2fSaleReport%2fApplicationStatusReport1&ApplicationDateFrom='+getparsedateFormat(ApplicationDateFrom)+'&ApplicationDateTo='+getparsedateFormat(ApplicationDateTo)+'&RegionCode='+RegionCode+'&AreaCode='+AreaCode+'&TeamCode='+TeamCode+'&SalesCode='+SalesCode+'&DealerCode='+DealerCode+'&ShowroomCode='+ShowroomCode+'&OverrideFlag='+OverrideFlag+'&ApplicationNo='+ApplicationNo+'&ApplicationStatus=null&ContractDateFrom='+getparsedateFormat(ContractDateFrom)+'&ContractDateTo='+getparsedateFormat(ContractDateTo)+'&PrintBy=watcharin.k&rs:Command=Render&rc:Toolbar=True&rc:Parameters=False&rc:HTMLFragment=True&rs:Command=ClearSession&rs:Format=HTML4.0&rc:Zoom=Page Width'
        }
        window.open(url,"_blank")
      }


  {
    Array.prototype.forEach.call(ResultSearchData, (res) => {
      {
        resSearch.push({
          application_no: res.application_no,
          application_date: res.application_date,
          contract_no: res.contract_no,
          contract_date: res.contract_date,
          application_status_code: res.application_status_code,
          application_status: res.application_status,
          product_type: res.product_type,
          dealer_name_tha: res.dealer_name_tha,
          dealer_name_eng: res.dealer_name_eng,
          showroom_name_tha: res.showroom_name_tha,
          showroom_name_eng: res.showroom_name_eng,
          team_code: res.team_code,
          team_name_tha: res.team_name_tha,
          team_name_eng: res.team_name_eng,
          marketing_code: res.marketing_code,
          mkt_name_tha: res.mkt_name_tha,
          customer_name: res.customer_name,
          finance_amt: res.finance_amt,
          override_flag: res.override_flag,
          override_by: res.override_by,
        });
      }
    });
  }


  const groups = resSearch.reduce((keys, value) => {
    keys[value.team_name_tha] = [...(keys[value.team_name_tha] || []), value];
    return keys;
  }, {});

  function getDealeridByCode(e){
    let x;
    dealeroptions.map(ma =>{
      if(e == ma.value){
        x = ma.dealer_id
      }
    })
    return x
  }
  
  let filteredShowroom = showroomoptions.filter(ss=>{
    return ss.dealer_id === getDealeridByCode(DealerCode)
  })


  function getRegionidByCode(e){
    let x;
    regionoptions.map(ma =>{
      if(e == ma.value){
        x = ma.region_id
      }
    })
    return x
  }
  
  let filteredArea = areaoptions.filter(ss=>{
    return ss.region_id === getRegionidByCode(RegionCode)
  })

  function getZoneidByAreaCode(e){
    let x;
    areaoptions.map(ma =>{
      if(e == ma.value){
        x = ma.zone_id
      }

    })
    return x
  }
  let filteredTeam = teamoptions.filter(ss=>{
    return ss.zone_id === getZoneidByAreaCode(AreaCode)
  })
  function getTeamidByTeamCode(e){
    let x;
    teamoptions.map(ma =>{
      if(e == ma.value){
        x = ma.team_id
      }
    })
    return x
  }
  let filteredSale = salecodetions.filter(ss=>{  
    return ss.team_id === getTeamidByTeamCode(TeamCode)
  })
  
  return (
    <div className="container-fluid">
      <div style={{background:"#fff", marginBottom:"10px", borderRadius:"0.25em"}}>
        <h3 style={{padding:"0.75rem 1.25rem" ,borderLeft:"4px solid red"}}>Application Status Report</h3>
     </div>
      <div className="card card-default">
          <div className="card-header">
            <h3 className="card-title">Search Criteria</h3>
            <div className="card-tools" style={{float: "right", marginTop: "-40px" }} >
              {/* <button
                type="button"
                className="btn btn-success"
                id="btnSearch"
                onClick={getResultSearch}
              >
                <i className="fas fa-search"></i> Search{" "}
              </button> */}

              <button
                type="button"
                className="btn btn-success"
                id="btnSearch"
                onClick={getGeneratePFD}
                style={{ marginRight: 5 }}
              >
                <i className="fas fa-search"></i> Search{" "}
              </button>
{/*     
              <button type="button" className="btn btn-succes" id="btnPdf" onClick={getGeneratePFD}>
                <i className="fas fa-download"></i> Generate PDF
              </button> */}

            </div>
          </div>
 
        <div className="card-body">
          <div className="row">
            <div className="col-md-4">
              <div className="form-group">
                <label>Application No</label>
                <input
                  type="text"
                  className="form-control"
                  id="ApplicationNo"
                  onChange={(event) => {
                    setApplicationNo(event.target.value);
                  }}
                />
              </div>
            </div>
            <div className="col-md-2">
              <div className="form-group">
                <label>Application Date From</label>
                <div
                  className="input-group date"
                  id="ApplicationDateFrom"
                  data-target-input="nearest"
                >
                  <DatePicker
                    selected={ApplicationDateFrom}
                    onChange={(date) => setApplicationDateFrom(date)}
                    showMonthDropdown={true}
                    dateFormat="dd/MM/yyy"
                    showYearDropdown={true}
                    dropdownMode="scroll"
                    className="form-control"
                  />
                </div>
              </div>
            </div>
            <div className="col-md-2">
              <div className="form-group">
                <label>Application Date To</label>
                <div
                  className="  date"
                  id="ApplicationDateTo"
                  data-target-input="nearest"
                >
                  <DatePicker
                    selected={ApplicationDateTo}
                    onChange={(date) => setApplicationDateTo(date)}
                    showMonthDropdown={true}
                    showYearDropdown={true}
                    dateFormat="dd/MM/yyy"
                    dropdownMode="scroll"
                    className="form-control"
                  />
                </div>
              </div>
            </div>
            <div className="col-md-2">
              <label>Contract Date From</label>
              <div
                className="  date"
                id="AppContractDateFrom"
                data-target-input="nearest"
              >
                <DatePicker
                  selected={ContractDateFrom}
                  onChange={(date) => setContractDateFrom(date)}
                  showMonthDropdown={true}
                  showYearDropdown={true}
                  dateFormat="dd/MM/yyy"
                  dropdownMode="scroll"
                  className="form-control"
                />
              </div>
            </div>
            <div className="col-md-2">
              <label>Contract Date To</label>
              <div
                className="input-group date"
                id="AppContractDateTo"
                data-target-input="nearest"
              >
                
                <DatePicker
                  selected={ContractDateTo}
                  onChange={(date) => setContractDateTo(date)}
                  showMonthDropdown={true}
                  showYearDropdown={true}
                  dateFormat="dd/MM/yyy"
                  dropdownMode="scroll"
                  className="form-control"
                />
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-md-4">
              <div className="form-group">
                <label>Application Status</label>
                <Select
                  options={Appstatusoptions}
                  closeMenuOnSelect={false}
                  components={animatedComponents}
                  //  defaultValue={[options[4], options[5]]}
                  isMulti
                  onChange={handleChangeStatus}
                />
              </div>
            </div>

            <div className="col-md-3" data-select2-id="2318">
              <div className="form-group">
                <label>Dealer code </label>
                <Select
                  defaultValue={[dealeroptions[0], dealeroptions[0]]}
                  options={dealeroptions}
                  onChange={handleChangeDealer}
                />
              </div>
            </div>
            <div className="col-md-3">
              <div className="form-group">
                <label>Show Room Code </label>
                <select className="form-control" id="select-area" style={{color:"rgb(51 51 51)"}} onChange={(e) => setShowroomCode(e.target.value)}>
                    <option value={null} defaultChecked>ทั้งหมด</option>
                      {filteredShowroom.map(fbb =>
                        <option key={fbb.value} value={fbb.value}>{fbb.label}</option>
                      )};
                </select>
 
              </div>
            </div>
            <div className="col-md-2">
              <div className="form-group">
                <label>Override </label>
                <select
                  className="form-control"
                  id="Override"
                  onChange={(e) => setOverrideFlag(e.target.value)}
                >
                  <option value="null" defaultChecked>
                    ทั้งหมด
                  </option>
                  <option value="1">YES</option>
                  <option value="0">-</option>
                </select>
              </div>
            </div>
          </div>

          <div className="row">
            <di className="col-md-3">
              <div className="form-group">
                <label>Sale Region</label>
                <Select
                  options={regionoptions}
                  defaultValue={[regionoptions[0], regionoptions[0]]}
                  onChange={handleChangeRegion}
                />
              </div>
            </di>
            <div className="col-md-3">
              <div className="form-group">
                <label>Sale Area</label>
                <select className="form-control" id="select-area" style={{color:"rgb(51 51 51)"}} onChange={handleChangeArea}>
                    <option value={null} defaultChecked>ทั้งหมด</option>
                      {filteredArea.map(fbb =>
                        <option key={fbb.value} value={fbb.value}>{fbb.label}</option>
                      )}
                </select>
              </div>
            </div>
            <div className="col-md-3" data-select2-id="2325">
              <div className="form-group">
                <label>Team code </label>
                <select className="form-control" style={{color:"rgb(51 51 51)"}} onChange={(e) => setTeamCode(e.target.value) }>
                    <option value={null} defaultChecked>ทั้งหมด</option>
                      {filteredTeam.map(fbb =>
                        <option key={fbb.value} value={fbb.value}>{fbb.label}</option>
                      )}
                </select>
              </div>
            </div>
            <div className="col-md-3">
              <div className="form-group">
                <label>Sale Code </label>
                <select className="form-control" style={{color:"rgb(51 51 51)"}} id="selectsale" onChange={(e) => setSalesCode(e.target.value)}>
                    <option value={null} defaultChecked>ทั้งหมด</option>
                      {filteredSale.map(fbb =>
                        <option key={fbb.value} value={fbb.value}>{fbb.label}</option>
                      )}
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-body">
          <div className="content__header">
            <div className="logo__sreport"></div>
            <div className="criteria__search"></div>
            <div className="detaile__print"></div>
          </div>

          <table
            style={{ fontSize: "12px", width: "100%" }}
            className="table table-sm"
          >
            {Object.entries(groups).map(([teams, teamval]) => {
              var x = 0.0;
              return (
                <tbody key={teams}>
                  <tr
                    style={{
                      backgroundColor: "#D6EAF8",
                      textAlign: "left",
                      fontWeight: "bold",
                    }}
                  >
                    <td colSpan="13" style={{ padding: "4px 2px" }}>
                      Team code - Name : {teams}
                    </td>
                  </tr>
                  <tr>
                    <th style={{ textAlign: "center" }}>Application No</th>
                    <th style={{ textAlign: "center" }}>Application Date</th>
                    <th style={{ textAlign: "center" }}>Application Status</th>
                    <th style={{ textAlign: "center" }}>Contract No</th>
                    <th style={{ textAlign: "center" }}>Contract Date </th>
                    <th style={{ textAlign: "center" }}>Product Type</th>
                    <th>Dealer name (showroom name)</th>
                    <th style={{ textAlign: "center" }}>Sale Code</th>
                    <th>Sale Name</th>
                    <th>Customer Name</th>
                    <th style={{ textAlign: "center" }}>Finance Amt</th>
                    <th style={{ textAlign: "center" }}>Override</th>
                    <th style={{ textAlign: "center" }}>Override by</th>
                  </tr>
                  {teamval.map((res, index) => {
                    x += res.finance_amt;
                    return (
                      <tr key={index}>
                        <td style={{ textAlign: "center" }}>
                          {res.application_no}
                        </td>
                        <td style={{ textAlign: "center" }}>
                          {res.application_date}
                        </td>
                        <td style={{ textAlign: "center" }}>
                          {res.application_status}
                        </td>
                        <td style={{ textAlign: "center" }}>
                          {res.contract_no}
                        </td>
                        <td style={{ textAlign: "center" }}>
                          {res.contract_date}
                        </td>
                        <td style={{ textAlign: "center" }}>
                          {res.product_type}
                        </td>
                        <td>
                          {res.dealer_name_tha +
                            "(" +
                            res.showroom_name_tha +
                            ")"}
                        </td>
                        <td style={{ textAlign: "center" }}>
                          {res.marketing_code}
                        </td>
                        <td>{res.mkt_name_tha}</td>
                        <td>{res.customer_name}</td>
                        <td style={{ textAlign: "center" }}>
                          {res.finance_amt}
                        </td>
                        <td style={{ textAlign: "center" }}>
                          {res.override_flag}
                        </td>
                        <td style={{ textAlign: "center" }}>
                          {res.override_by}
                        </td>
                      </tr>
                    );
                  })}
                  <tr style={{ fontWeight: "bold" }}>
                    <td colSpan="5" style={{ textAlign: "right" }}>
                      {teams}
                    </td>
                    <td
                      style={{
                        textAlign: "center",
                        padding: "5px 0 15px 0",
                        backgroundColor: "#D6EAF8",
                        borderBottomStyle: "double",
                      }}
                    >
                      {teamval.length}
                    </td>
                    <td colSpan="2" style={{ textAlign: "right" }}>
                      Total Finance Amt.
                    </td>
                    <td
                      style={{
                        padding: "5px 0 15px 0",
                        backgroundColor: "#D6EAF8",
                        textAlign: "right",
                        borderBottomStyle: "double",
                      }}
                    >
                      {/* {new Intl.NumberFormat('en-IN',{}).format(x)} */}
                      <NumberFormat
                        value={x.toFixed(2)}
                        displayType={"text"}
                        thousandSeparator={true}
                        prefix={""}
                      />
                    </td>
                    <td colSpan="4"></td>
                  </tr>
                  <br />
                </tbody>
              );
            })}
          </table>
        </div>
      </div>
    </div>
  );
};

export default AppcationStatusReport;
