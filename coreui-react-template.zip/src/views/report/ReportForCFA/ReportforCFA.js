import React from 'react'




const ReportForCFA = () => {
    return(
        <td onClick={()=> window.open("http://desktop-td39fih/ReportServer/Pages/ReportViewer.aspx?%2ftestReport%2fReport2&ApplicationDateFrom=2020-10-01&ApplicationDateTo=2020-10-01&RegionCode=null&AreaCode=null&TeamCode=null&SalesCode=null&DealerCode=null&ShowroomCode=null&OverrideFlag=null&ApplicationNo=null&ApplicationStatus=null&ContractDateFrom=null&ContractDateTo=null&rs:Format=PDF", "_blank")}>Generate PDF</td>
    );
}

export default ReportForCFA;