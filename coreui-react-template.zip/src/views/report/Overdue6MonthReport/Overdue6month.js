import React, { useState, useEffect } from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/src/stylesheets/datepicker.scss";
import axios from "axios";
import Select from "react-select";
import MasterApiController from '../../../service/controller/MasterApiController'

const Overdue6Month = () => {

  const [regionErrors, setRegionErrors] = useState(false);
  const [regionData, setRegions] = useState({});

  const [areaErrors, setAreaErrors] = useState(false);
  const [areaData, setAreas] = useState({});

  const [saleteamErrors, setSaleteamErrors] = useState(false);
  const [saleteamData, setSaleteams] = useState({});

  const [salecodeErrors, setSalecodeErrors] = useState(false);
  const [salecodeData, setSalecodes] = useState({});

  const master  = new MasterApiController();

  async function getAllRegion() {
    const value = await master.getAllRegion();
    setRegions(value)

  }

  async function getAllArea() {
    const value = await master.getAllArea();
    setAreas(value)

  }

  async function getAllSaleteam() {
    const value = await master.getAllSaleteam();
    setSaleteams(value)

  }

  async function getAllSalecode() {
    const value = await master.getAllSalecode();
    setSalecodes(value)
  }

  useEffect(() => {
    getAllRegion();
    getAllArea();
    getAllSaleteam();
    getAllSalecode();
    
  }, []);
  // axios({
  //   method: "post",
  //   url: "/api/RegionMaster",
  //   headers: {
  //     "Content-Type": "application/json",
  //   },
  // })
  //   .then((response) => {
  //     setRegions(response.data);
  //   })
  //   .catch((err) => {
  //     setRegionErrors(err);
  //     console.error(err);
  //   });
  // axios({
  //   method: "post",
  //   url: "/api/AreaMaster",
  //   headers: {
  //     "Content-Type": "application/json",
  //   },
  // })
  //   .then((response) => {
  //     setAreas(response.data);
  //   })
  //   .catch((err) => {
  //     setAreaErrors(err);
  //     console.error(err);
  //   });
  // axios({
  //   method: "post",
  //   url: "/api/MarketingTeamMaster",
  //   headers: {
  //     "Content-Type": "application/json",
  //   },
  // })
  //   .then((response) => {
  //     setSaleteams(response.data);
  //   })
  //   .catch((err) => {
  //     setSaleteamErrors(err);
  //     console.error(err);
  //   });
  // axios({
  //   method: "post",
  //   url: "/api/MarketingStaffMaster",
  //   headers: {
  //     "Content-Type": "application/json",
  //   },
  // })
  //   .then((response) => {
  //     setSalecodes(response.data);
  //   })
  //   .catch((err) => {
  //     setSalecodeErrors(err);
  //     console.error(err);
  //   });
  const [AppDataASOfDate, setAppDataASOfDate] = useState(new Date());
  const [AppFirstDueDateFrom, setAppFirstDueDateFrom] = useState(null);
  const [AppFirstDueDateTo, setAppFirstDueDateTo] = useState(null);
  const [ContractNo, setContractNo] = useState(null);
  const [RegionCode, setRegionCode] = useState(null);
  const [AreaCode, setAreaCode] = useState(null);
  const [TeamCode, setTeamCode] = useState(null);
  const [SalesCode, setSalesCode] = useState(null);
  const [DataListFlag, setDataListFlag] = useState(0);
  const [OverrideStatus, setOverrideStatus] = useState(null);

  const regionoptions = [{ region_id: null,value: 0, label: "All" }];
  {
    for (var i = 0; i < regionData.length; i++) {
      {
        regionoptions.push({
          region_id : regionData[i].region_id,
          value: regionData[i].region_code,
          label: regionData[i].region_name_tha,
        });
      }
    }
  }

const areaoptions = [/*{ zone_id: null ,value: null, label: "ทั้งหมด",region_id: null  }*/];
  {
    for (var i = 0; i < areaData.length; i++) {
      {
        areaoptions.push({
          zone_id: areaData[i].zone_id,
          value: areaData[i].zone_code,
          label: areaData[i].zone_name_tha,
          region_id:  areaData[i].region_id,
        });
      }
    }
  }

  const teamoptions = [/*{team_id: null ,value: null, label: "ทั้งหมด",  zone_id:null }*/];
  {
    for (var i = 0; i < saleteamData.length; i++) {
      {
        teamoptions.push({
          team_id: saleteamData[i].team_id,
          value: saleteamData[i].team_code,
          label: saleteamData[i].team_name_tha,
          zone_id: saleteamData[i].zone_id,
        });
      }
    }
  }

  const salecodetions = [/*{ team_id:null, value: null, label: "ทั้งหมด" }*/];
  {
    for (var i = 0; i < salecodeData.length; i++) {
      {
        salecodetions.push({
          team_id: salecodeData[i].team_id,
          value: salecodeData[i].marketing_code,
          label: salecodeData[i].mkt_full_name_tha,
        });
      }
    }
  }

  const handleChangeFirstDateTo = date =>{
    setAppFirstDueDateTo(date)
    let lates = new Date(date.getFullYear(),date.getMonth()-5,date.getDate())
    setAppFirstDueDateFrom(lates)
  }
  const handleChangeContract = (e) => {
    if (e.value!==null || e.value!=="") {
      setContractNo(e.value);
    } else {
      setContractNo(null);
    }
  };
  
  const handleChangeRegion = (e) => {
    setAreaCode(null);
    setTeamCode(null);
    setSalesCode(null);
    if (e.value!==null || e.value!=="") {
      setRegionCode(e.value);
    } else {
      setRegionCode(null);
    }
  };
  const handleChangeArea = (e) => {
    setTeamCode(null);
    setSalesCode(null);
    if (e.target.value!==null || e.target.value!=="") {
      setAreaCode(e.target.value);
    } else {
      setAreaCode(null);
    }
  };
  const handleChangeTeamCode = (e) => {
    if (e.value!==null || e.value!=="") {
      setTeamCode(e.value);
    } else {
      setTeamCode(null);
    }
  };
  const handleChangeSaleCode = (e) => {
    if (e.value!==null || e.value!=="") {
      setSalesCode('"'+e.value+'"')
    } else {
      setSalesCode(null);
    }
  };
    function getparsedateFormat(value) {
      if (value === null || value=== "") {
        return null;
      } else {
        const ye = new Intl.DateTimeFormat("en", { year: "numeric" }).format(value);
        const mo = new Intl.DateTimeFormat("en", { month: "2-digit" }).format(value);
        const da = new Intl.DateTimeFormat("en", { day: "2-digit" }).format(value);
        const result = ye + "-" + mo + "-" + da;
        return result;
      }
    }
    function  AddLastDayTOdate(value) {
      if (value === null || value=== "") {
        return null;
      } else {
        const ye = new Intl.DateTimeFormat("en", { year: "numeric" }).format(value);
        const mo = new Intl.DateTimeFormat("en", { month: "2-digit" }).format(value);
        let da = 31;

        if (parseInt(mo) === 2) {
          if (parseInt(ye) %4 !==0 ) {
            da = 28;
          } else if (parseInt(ye) % 100 !==0 ) {
            da = 29;
          } else if (parseInt(ye) % 400 !== 0 ) {
            da = 28;
          } else {
            da = 29;
          }
        } else if (parseInt(mo) === 4 || parseInt(mo) === 6 || parseInt(mo) === 9 || parseInt(mo) === 11) {
          da = 30;
        }
        const result = ye + "-" + mo + "-" + da;
        return result;
      }
    }

    const getExportExcal = () =>{
        window.open('http://desktop-td39fih/ReportServer/Pages/ReportViewer.aspx?%2ftestReport%2fOverdue6MonthExport&DataASOfDate='+getparsedateFormat(AppDataASOfDate)+'&RegionCode='+RegionCode+'&AreaCode='+AreaCode+'&TeamCode='+TeamCode+'&SalesCode='+SalesCode+'&DataListFlag='+DataListFlag+'&OverrideStatus='+OverrideStatus+'&ContractNo='+ContractNo+'&FirstDueDateFrom='+getparsedateFormat(AppFirstDueDateFrom)+'&FirstDueDateTo='+AddLastDayTOdate(AppFirstDueDateTo)+'&rs:Format=excel', '_blank');
    }
    const getGenerat = () =>{
      window.open('http://desktop-td39fih/ReportServer/Pages/ReportViewer.aspx?%2ftestReport%2fOverdue6MonthReport&DataASOfDate='+getparsedateFormat(AppDataASOfDate)+'&RegionCode='+RegionCode+'&AreaCode='+AreaCode+'&TeamCode='+TeamCode+'&SalesCode='+SalesCode+'&DataListFlag='+DataListFlag+'&OverrideStatus='+OverrideStatus+'&ContractNo='+ContractNo+'&FirstDueDateFrom='+getparsedateFormat(AppFirstDueDateFrom)+'&FirstDueDateTo='+AddLastDayTOdate(AppFirstDueDateTo)+'&PrintBy=watcharin.k&rs:Command=Render&rc:Toolbar=True&rc:Parameters=False&rc:HTMLFragment=True&rs:Command=ClearSession&rs:Format=HTML4.0&rc:Zoom=Page Width','_blank');
    }
    
    function getRegionidByCode(e){
      let x;
      regionoptions.map(ma =>{
        if(e === ma.value){
          x = ma.region_id
        }
      })
      return x
    }
    
    let filteredArea = areaoptions.filter(ss=>{
      return ss.region_id === getRegionidByCode(RegionCode)
    })

    function getZoneidByAreaCode(e){
      let x;
      areaoptions.map(ma =>{
        if(e === ma.value){
          x = ma.zone_id
        }

      })
      return x
    }
    let filteredTeam = teamoptions.filter(ss=>{
      return ss.zone_id === getZoneidByAreaCode(AreaCode)
    })
    function getTeamidByTeamCode(e){
      let x;
      teamoptions.map(ma =>{
        if(e === ma.value){
          x = ma.team_id
        }
      })
      return x
    }
    let filteredSale = salecodetions.filter(ss=>{  
      return ss.team_id === getTeamidByTeamCode(TeamCode)
    })

  return (
    <div className="container-fluid">
     <div style={{background:"#fff", marginBottom:"10px", borderRadius:"0.25em"}}>
        <h3 style={{padding:"0.75rem 1.25rem" ,borderLeft:"4px solid red"}}>Overdue 6 Month Report</h3>
     </div>
      {/* SELECT2 EXAMPLE */}
      <div className="card card-default" id="div1">
          <div className="card-header">
            {/* <h3 className="card-title" style={{ fontWeight: "bold" }}>
              Search Criteria
            </h3> */}
            <div className="card-tools" style={{display: 'flex', justifyContent: 'flex-end'}} /*style={{  float: "right" , marginTop: "-40px"}}*/>
            <button
                type="button"
                className="btn btn-success"
                id="btnExcal"
                style={{ marginRight: 5 }}
                onClick={getExportExcal}
              >
                <i className="fas fa-search" /> Export to Excal
              </button>
              <button
                type="button"
                className="btn btn-success"
                id="btnSearch"
                style={{ marginRight: 5 }}
                onClick={getGenerat}
              >
                <i className="fas fa-search" /> Search
              </button>
            </div>
          </div>
        <div className="card-body">
          <div className="row">
            <div className="col-md-2">
              <div className="form-group">
                <label style={{ padding: 0, margin: 0 }}>Data as of</label>
                <div
                  className="input-group date"
                  id="AppDataASOfDate"
                  data-target-input="nearest"
                >
                  <DatePicker
                    selected={AppDataASOfDate}
                    onChange={(date) => setAppDataASOfDate(date)}
                    showMonthDropdown={true}
                    dateFormat="dd/MM/yyy"
                    showYearDropdown={true}
                    dropdownMode="scroll"
                    className="form-control"
                  />
                </div>
              </div>
            </div>
            <div className="col-md-2">
              <label style={{ padding: 0, margin: 0 }}>
                First Due Date From
              </label>
              <div
                className="input-group date"
                id="AppFirstDueDateFrom"
                data-target-input="nearest"
              >
                  <DatePicker
                    selected={AppFirstDueDateFrom}
                    onChange={(date) => setAppFirstDueDateFrom(date)}
                    showMonthYearPicker
                    dateFormat="MM/yyyy"
                    showFullMonthYearPicker
                    
                    showTwoColumnMonthYearPicker
                    className="form-control"
                  />
              </div>
            </div>
            <div className="col-md-2">
              <label style={{ padding: 0, margin: 0 }}>First Due Date To</label>
              <div
                className="input-group date"
                id="AppFirstDueDateTo"
                data-target-input="nearest"
              >
                <DatePicker
                    selected={AppFirstDueDateTo}
                    onChange={handleChangeFirstDateTo}
                    showMonthYearPicker
                    dateFormat="MM/yyyy"
                    showFullMonthYearPicker
                    showTwoColumnMonthYearPicker
                    className="form-control"
                  />
              </div>
            </div>
            <div className="col-md-2">
              <div className="form-group">
                <label style={{ padding: 0, margin: 0 }}>Contract No</label>
                <input
                  type="text"
                  className="form-control"
                  id="ContractNo"
                  onChange={handleChangeContract}
                />
              </div>
            </div>
            <div className="col-md-2">
              <div className="form-group" >
                <label style={{ padding: 0, margin: 0 }}>Data List </label>
                <select className="form-control"  style={{color:"rgb(51 51 51)"}} id="DataList" onChange={(e) => setDataListFlag(e.target.value)}>
                  <option value={0} defaultChecked>Show all</option>
                  <option value={1}>Show only overdue</option>
                </select>
              </div>
            </div>
            <div className="col-md-2">
              <div  className="form-group" >
                <label style={{ padding: 0, margin: 0 }}>
                  Override Status{" "}
                </label>
                <select className="form-control"  style={{color:"rgb(51 51 51)"}} id="OverrideStatus" onChange={(e) => setOverrideStatus(e.target.value) }>
                  <option value="null" defaultChecked>ทั้งหมด</option>
                  <option value={1}>Override</option>
                  <option value={0}>Normal</option>
                </select>
              </div>
            </div>
          </div>
          <div className="row">
            <div className="col-md-3">
              <div className="form-group" >
              <label>Sale Region</label>
                <Select
                  options={regionoptions}
                  defaultValue={[regionoptions[0], regionoptions[0]]}
                  onChange={handleChangeRegion}
                />
              </div>
            </div>
            <div className="col-md-3">
              <div className="form-group">
              <label>Sale Area</label>

                <select className="form-control css-yk16xz-control" id="select-area" style={{color:"rgb(51 51 51)"}} onChange={handleChangeArea}>
                  
                    <option value={null} defaultChecked>ทั้งหมด</option>
                      {filteredArea.map(fbb =>
                        <option key={fbb.value} value={fbb.value}>{fbb.label}</option>
                      )}
                </select>
                {/* <Select id="selectarea" options={filteredArea}  onChange={handleChangeArea} /> */}
              </div>
            </div>
            <div className="col-md-3">
              <div className="form-group" >
              <label>Team code </label>
              <select className="form-control" style={{color:"rgb(51 51 51)"}} onChange={(e) => setTeamCode(e.target.value) }>
                    <option value={null} defaultChecked>ทั้งหมด</option>
                      {filteredTeam.map(fbb =>
                        <option key={fbb.value} value={fbb.value}>{fbb.label}</option>
                      )}
                </select>
                {/* <Select options={filteredTeam}  onChange={handleChangeTeamCode} /> */}
              </div>
            </div>
            <div className="col-md-3">
              <div className="form-group" >
              <label>Sale Code </label>
              <select className="form-control" style={{color:"rgb(51 51 51)"}} id="selectsale" onChange={(e) => setSalesCode(e.target.value)}>
                    <option value={null} defaultChecked>ทั้งหมด</option>
                      {filteredSale.map(fbb =>
                        <option key={fbb.value} value={fbb.value}>{fbb.label}</option>
                      )}
                </select>
                {/* <Select options={filteredSale} onChange={handleChangeSaleCode}/> */}
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* /.container-fluid */}
    </div>
  );
};

export default Overdue6Month;
