import React, { useState } from "react";
import { Link } from "react-router-dom";

import CIcon from "@coreui/icons-react";
import axios from "axios";

import LoginController from '../../../service/controller/LoginController'
import Logins from '../../../model/Login'
import {AuthContext} from './context';
export default function Login () {
  const [account, setAccount] = useState({ username: '', password: '' });
  // const {signin} = React.useContext(AuthContext);
  const submitHandle = (e) => {
    e.preventDefault();

    if(account.username === '' || account.password === ''){
      console.log("username or password null")
    }else{
        let l = new LoginController();
        let lo = new Logins();
        lo.username = account.username;
        lo.password = account.password;
        let result =  l.doLogin(lo)
        console.log('login',result)
        if(result === 1){
          // signin(lo.username,lo.password) 
          console.log("RESULT 1")  
        }else{
           console.log("resule = 0")
        }
    }
  };

  // const [resultVerifylogin, setResultVerify] = useState({});
  // const [resultAuth, setResultsAuth] = useState({});
/*
  async function verifyLogin(username, password) {
    axios({
      method: "post",
      url: "http://115.31.145.20/srisawad-api/api/Authentication/IsLoggedIn",
      headers: {
        "Content-Type": "application/json",
      },
      data: { username: username, password: password, grantType: "password" },
    })
      .then((response) => {
        setResultVerify(response.data);
        console.log("ResultVerify : ", response.data);
        if (response.data.Success === true) {
          roleDescription(username);
        }
      })
      .catch((err) => {
        console.error(err);
      });
  }

  async function roleDescription(username) {
    axios({
      method: "post",
      url: "http://115.31.145.20/srisawad-api/api/Authentication/auth",
      headers: {
        "Content-Type": "application/json",
      },
      data: { username: username, grantType: "password" },
    })
      .then((response) => {
        setResultsAuth(response.data.authToken);
        console.log("ResultVerify : ", response.data.authToken);
      })
      .catch((err) => {
        console.error(err);
      });
  }
*/
  return (
    <div className="c-app c-default-layout flex-row align-items-center">
      <div className="container">
        <div className="row justify-content-center">
          <div style={{ width: "350px" }}>
            <div className="card-group">
              <div className="card p-4">
                <div className="card-body">
                  <form method="post">
                    <h1>Login</h1>
                    <p className="text-muted">Sign In to your account</p>
                    <div className="input-group mb-3">
                      <div className="input-group-prepend">
                        <div className="input-group-text">
                          <CIcon name="cil-user" />
                        </div>
                      </div>
                      <input
                        type="text"
                        className="form-control"
                        id="Username"
                        name="Username"
                        placeholder="User Name"
                        onChange={(e) => {
                          setAccount({ ...account, username: e.target.value });
                        }}
                      />
                    </div>
                    <div className="input-group mb-3">
                      <div className="input-group-prepend">
                        <div className="input-group-text">
                          <CIcon name="cil-lock-locked" />
                        </div>
                      </div>
                      <input
                        type="password"
                        className="form-control"
                        id="Password"
                        name="Password"
                        placeholder="Password"
                        onChange={(e) => {
                          setAccount({ ...account, password: e.target.value });
                        }}
                      />
                    </div>
                    <div className="row">
                      <div className="col-xs-6">
                        <button
                          type="submit"
                          color="primary"
                          onClick={submitHandle}
                          className="btn btn-primary btn-block px-4"
                        >
                          Sign In
                        </button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
              {/* <div className="card text-white bg-primary py-5 d-md-down-none">
                <div className="card-body text-center">
                  <div>
                      <h2>Sign up</h2>
                      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua.</p>
                      <Link to="/register">
                        <CButton color="primary" className="mt-3" active tabIndex={-1}>Register Now!</CButton>
                      </Link>
                    </div>
                </div>
              </div> */}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
