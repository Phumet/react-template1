import React, { useState, useEffect } from "react";


const CreditCalculate = () => {

    const [categorysize,setCategorysize] = useState("moto")
    const radioChange = e =>{
        setCategorysize(e.currentTarget.value)
    }
    const [price, setPrice] = useState({ price: "", priceDown: "" , downPercent:"" ,financeAmount:"" ,fianceTerm:12 ,rate : "" ,installment:"", message:""});

    const handleChangePrice = event =>{
        const re = /^-?\d*[,.]?(\d{0,3},)*(\d{3},)?\d{0,3}$/;
        event.target.value = numberSeparator(event.target.value);
        if (event.target.value === '' || re.test(event.target.value)) {
            setPrice({ ...price, price: event.target.value.replace(/\,/g, ''), downPercent: ((price.priceDown/event.target.value.replace(/\,/g, '') )* 100).toFixed(2) ,financeAmount : (event.target.value.replace(/\,/g, '') -price.downPercent)})
            if (event.target.value==='') {
                setPrice({...price, price: event.target.value, downPercent:"" , financeAmount:""})
            }
        }
    }
    const handleChangePriceDown = event =>{
        const re = /^-?\d*[,.]?(\d{0,3},)*(\d{3},)?\d{0,3}$/;
        event.target.value = numberSeparator(event.target.value);
        if (event.target.value === '' || re.test(event.target.value)) {
            setPrice({ ...price, priceDown: event.target.value.replace(/\,/g, ''), downPercent: ((event.target.value.replace(/\,/g, '')/price.price )* 100).toFixed(2),financeAmount : (price.price-event.target.value.replace(/\,/g, ''))})
            if (event.target.value==='') {
                setPrice({...price, priceDown: event.target.value, downPercent:"" , financeAmount:""})
            }
        }

    }

    const handleChangeDownpercent = event =>{
        const re = /^-?\d*[,.]?(\d{0,3},)*(\d{3},)?\d{0,3}$/;
        event.target.value = numberSeparator(event.target.value);
        if (event.target.value === '' || re.test(event.target.value)) {
            setPrice({ ...price, downPercent: event.target.value, priceDown: ((price.price*event.target.value.replace(/\,/g, '') )/ 100).toFixed(2)})
            if (event.target.value==='') {
                setPrice({...price, priceDown: "", downPercent:""})
            }
        }
    }

    const handleChangeRate = event =>{
        const re = /^-?\d*[,.]?(\d{0,3},)*(\d{3},)?\d{0,3}$/;
        event.target.value = numberSeparator(event.target.value);
        if (event.target.value === '' || re.test(event.target.value)) {
            setPrice({ ...price, rate : event.target.value})
            if (event.target.value==='') {
                setPrice({ ...price, rate : event.target.value})
            }
        }
    }

    var commaCounter = 10;
    function numberSeparator(Number) {
        Number += '';

        for (var i = 0; i < commaCounter; i++) {
            Number = Number.replace(',', '');
        }

       let x = Number.split('.');
       let y = x[0];
       let z = x.length > 1 ? '.' + x[1] : '';
        var rgx = /(\d+)(\d{3})/;

        while (rgx.test(y)) {
            y = y.replace(rgx, '$1' + ',' + '$2');
        }
        commaCounter++;
        return y + z;
    }
    const handleReset= () =>{
        setPrice({price: "", priceDown: "" , downPercent:"" ,financeAmount:"" ,fianceTerm:12 ,rate : "" ,installment:"", message:""})
    }
    const CalInstallMent= () => {
        let unlealize = 0
        let p_installment = 0.0000
        let p_price = parseFloat(price.financeAmount)
        let p_rate = parseFloat(price.rate)
        p_price.toFixed(4)
        p_rate.toFixed(2)

        if (categorysize == 'moto') {
            console.log("MOTO")
            unlealize = p_price * (p_rate / 100.00) * (price.fianceTerm)
        } else {
            console.log("BIKE")
            unlealize = p_price * (p_rate / 100.00) * (price.fianceTerm / 12)
        }

        unlealize.toFixed(4)
        p_installment = Math.ceil((p_price + unlealize) / price.fianceTerm)
   
        setPrice({...price, installment: p_installment.toFixed(0) ,message:""})

        let p_realize = ((p_installment * price.fianceTerm) - p_price)
        if (categorysize == 'moto') {
            if (price.fianceTerm >= 42 && p_realize < 15000) {
                setPrice({...price, installment: "" , message:"ดอกเบี้ยรับ น้อยกว่า 15,000 กรุณาคำนวนใหม่"})
            }else if(price.fianceTerm >=24 && p_realize < 10000){
                setPrice({...price, installment: "" , message:"ดอกเบี้ยรับ น้อยกว่า 10,000 กรุณาคำนวนใหม่"})
            }else if(price.fianceTerm >= 12 &&  p_realize < 7000){
                setPrice({...price, installment: "" , message:"ดอกเบี้ยรับ น้อยกว่า 7,000 กรุณาคำนวนใหม่"})
            }
        }
    }
    
    return(
        <div className="container">
            <div style={{background:"#fff", marginBottom:"10px", borderRadius:"0.25em"}}>
                <h3 style={{padding:"0.75rem 1.25rem" ,borderLeft:"4px solid red", fontFamily:"'Kanit', sans-serif"}}>คำนวณสินเชื่อ</h3>
            </div>
                <div className="card" style={{fontFamily:"'Kanit', sans-serif"}}>
                    <div className="card-body">
                        <div className="row" style={{fontSize: 13}}>
                        <table style={{width: '100%'}}>
                            <tbody>
                                <tr>
                                    <td style={{width:'20%'}}></td>
                                    <td style={{width:'25%'}}></td>
                                    <td style={{width:'5%'}}></td>
                                    <td style={{width:'25%'}}></td>
                                    <td style={{width:'15%'}}></td>
                                    <td style={{width:'5%'}}></td>
                                </tr>
                            <tr>
                                <td colSpan={6} align="center">
                                <div className="form-group clearfix">
                                    <label className="require-field">* &nbsp;</label>
                                    <div className="icheck-primary d-inline">
                                    <input type="radio" id="rd_type_small" name="rd_type" value="moto" defaultChecked onChange={radioChange} />
                                        <label htmlFor="rd_type_small" style={{marginRight:15}}>
                                            Small (S),Medium (M) 
                                        </label>
                                    </div>
                                    <div className="icheck-primary d-inline">
                                    <input type="radio" id="rd_type_large" name="rd_type" value="bigbike" onChange={radioChange} />
                                        <label htmlFor="rd_type_large">
                                            Large (L)
                                        </label>
                                    </div>
                                </div>
                                </td>
                            </tr>
                            <tr>
                                <td align="right"><label className="col-form-label">ราคารถ &nbsp;<label className="require-field">*</label></label></td>
                                <td colSpan={4}><input type="text" className="form-control form-control-sm number-separator " id="txt_price" style={{textAlign: 'center'}}  pattern="[0-9]*" value={numberSeparator(price.price)}  onChange={handleChangePrice} /> </td>
                                <td><label className="col-form-label">บาท</label></td>
                            </tr>
                            <tr>
                                <td align="right"><label className="col-form-label">เงินดาวน์ &nbsp;</label></td>
                                <td><input type="text" className="form-control form-control-sm number-separator" id="txt_down_payment" style={{textAlign: 'center'}}  pattern="[0-9]*" value={numberSeparator(price.priceDown)} onChange={handleChangePriceDown} /></td>
                                <td><label className="col-form-label">บาท</label></td>
                                <td align="right"><label className="col-form-label">หรือ ดาวน์ &nbsp;</label></td>
                                <td><input type="text" className="form-control form-control-sm number-separator" id="txt_down_percent" style={{textAlign: 'center'}}  pattern="[0-9]*" value={price.downPercent} onChange={handleChangeDownpercent}  /></td>
                                <td><label className="col-form-label">%</label></td>
                            </tr>
                            <tr>
                                <td align="right"><label className="col-form-label">ยอดจัด &nbsp;</label></td>
                                <td colSpan={4}><input type="text" className="form-control form-control-sm number-separator" id="txt_finance_amount" value={numberSeparator(price.financeAmount)} readOnly style={{textAlign: 'center'}} /></td>
                                <td><label className="col-form-label">บาท</label></td>
                            </tr>
                            <tr>
                                <td align="right"><label className="col-form-label">ระยะเวลา &nbsp;<label className="require-field">*</label></label></td>
                                <td>
                                <select className="form-control select2 number-separator" style={{width: '100%'}} id="ls_fiance_term" onChange={(e) =>  setPrice({ ...price, fianceTerm : e.target.value}) }>
                                    <option defaultChecked value="12">12</option>
                                    <option value="18">18</option>
                                    <option value="24">24</option>
                                    <option value="29">29</option>
                                    <option value="30">30</option>
                                    <option value="32">32</option>
                                    <option value="36">36</option>
                                    <option value="42">42</option>
                                    <option value="48">48</option>
                                </select>
                                </td>
                                <td><label className="col-form-label">เดือน</label></td>
                                <td align="right"><label className="col-form-label"><span id="sp_rate_desc">อัตรา &nbsp;&nbsp;&nbsp;<br /> {categorysize == "moto"? "ต่อเดือน":"ต่อปี"}<label className="require-field">*</label></span></label></td>
                                <td><input type="text" className="form-control form-control-sm number-separator" id="txt_rate" pattern="[0-9]*" value={price.rate}  onChange={handleChangeRate} style={{textAlign: 'center'}} /></td>
                                <td><label className="col-form-label">%</label></td>
                            </tr>
                            <tr>
                                <td align="right"><label className="col-form-label">ค่างวด<br />ต่อเดือน</label></td>
                                <td colSpan={4}><input type="text" className="form-control form-control-sm number-separator" id="txt_installment" value={numberSeparator(price.installment)} readOnly style={{textAlign: 'center'}} /></td>
                                <td><label className="col-form-label">บาท</label></td>
                            </tr>
                            <tr>
                                <td colSpan={6} align="center"><label className="col-form-label"><span className="number-separator" id="l_realize" style={{color: 'red'}} value={price.message}>{price.message}</span></label></td>
                            </tr>
                            </tbody></table>
                        </div>
                    </div>
                 
                    <div className="card-footer" style={{display:"flex" , justifyContent:"center" ,columnGap:"2em"}}>
                        <button type="button" className="btn btn-info" onClick={CalInstallMent}>คำนวณ</button>
                        <button type="reset" className="btn btn-light float-right" onClick={handleReset}>เริ่มใหม่</button>
                    </div>
                </div>
        </div>


    );
}

export default CreditCalculate;